#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SLAM地图管理模块
负责：
- 订阅SLAM生成的地图
- 维护占有栅格信息
- 生成成本地图
"""

import numpy as np
import threading
from collections import deque
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import LaserScan
import scipy.ndimage as ndimage


class SlamMapHandler(Node):
    """SLAM地图处理类
    
    作用：
    1. 订阅/map话题（来自SLAM）
    2. 维护全局占有栅格
    3. 生成膨胀成本地图
    4. 提供栅格坐标转换
    """
    
    def __init__(self):
        super().__init__("slam_map_handler")
        
        # ==================== 地图存储 ====================
        self.map_data = None              # 原始地图数据
        self.cost_map = None              # 膨胀成本地图
        self.inflated_grid = None         # 膨胀后的占有栅格
        self.map_info = None              # 地图元数据
        
        # ==================== 地图参数 ====================
        self.map_resolution = 0.05        # 地图分辨率(m/cell)
        self.map_origin_x = 0.0           # 地图原点x
        self.map_origin_y = 0.0           # 地图原点y
        self.inflation_radius = 0.3       # 膨胀半径(m) = 机器人半径
        
        # ==================== 线程锁 ====================
        self.map_lock = threading.Lock()
        
        # ==================== ROS订阅 ====================
        qos_profile = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE)
        self.map_callback_group = MutuallyExclusiveCallbackGroup()
        
        # 订阅SLAM地图
        self.map_subscription = self.create_subscription(
            OccupancyGrid,
            "/map",                    # SLAM工具箱发布的地图话题
            self.map_callback,
            qos_profile,
            callback_group=self.map_callback_group
        )
        
        self.get_logger().info("SLAM Map Handler initialized")
    
    def map_callback(self, msg):
        """处理地图更新回调"""
        with self.map_lock:
            # ==================== 提取地图元数据 ====================
            self.map_info = msg.info
            self.map_resolution = msg.info.resolution
            self.map_origin_x = msg.info.origin.position.x
            self.map_origin_y = msg.info.origin.position.y
            
            # ==================== 转换地图数据 ====================
            self.map_data = np.array(
                msg.data,
                dtype=np.int8
            ).reshape((msg.info.height, msg.info.width))
            
            # 生成成本地图
            self.generate_cost_map()
            
            self.get_logger().debug(
                f"Map updated: {msg.info.width}x{msg.info.height} "
                f"@ {self.map_resolution}m/cell"
            )
    
    def generate_cost_map(self):
        """生成膨胀成本地图
        
        步骤：
        1. 将占有栅格（0-100）转换为二值图像
        2. 计算膨胀半径（以cell为单位）
        3. 使用最大滤波器膨胀障碍物
        4. 生成平滑的成本地图
        """
        if self.map_data is None:
            return
        
        # 步骤1：二值化占有栅格
        # -1=未知, 0=自由, 1-100=占有
        occupied = self.map_data > 50          # 50以上认为是障碍物
        unknown = self.map_data == -1
        
        # 步骤2：计算膨胀半径（cell单位）
        inflation_cells = int(
            np.ceil(self.inflation_radius / self.map_resolution)
        )
        
        # 步骤3：使用最大滤波器膨胀障碍物
        inflated = ndimage.maximum_filter(
            occupied.astype(np.uint8),
            size=2 * inflation_cells + 1
        )
        
        # 步骤4：生成成本地图
        self.inflated_grid = inflated
        
        # 计算到障碍物的距离
        distance = ndimage.distance_transform_edt(
            1 - inflated
        ) * self.map_resolution
        
        # 生成平滑成本地图
        # 距离越近，成本越高
        self.cost_map = np.exp(-distance / self.inflation_radius)
        
        # 标记未知区域为高成本
        self.cost_map[unknown] = 0.5
    
    def get_cost_at_position(self, x, y):
        """查询某位置的成本值
        
        参数：
            x (float): 世界坐标系x
            y (float): 世界坐标系y
        
        返回：
            float: 成本值(0-1)，越高越危险
        """
        if self.cost_map is None:
            return 0.0
        
        # 转换为栅格坐标
        grid_x = int((x - self.map_origin_x) / self.map_resolution)
        grid_y = int((y - self.map_origin_y) / self.map_resolution)
        
        # 边界检查
        if (0 <= grid_x < self.cost_map.shape[1] and
            0 <= grid_y < self.cost_map.shape[0]):
            return float(self.cost_map[grid_y, grid_x])
        
        return 1.0  # 超出地图返回最高成本
    
    def is_collision(self, x, y):
        """检查位置是否与障碍物碰撞
        
        参数：
            x (float): 世界坐标系x
            y (float): 世界坐标系y
        
        返回：
            bool: 是否碰撞
        """
        if self.inflated_grid is None:
            return False
        
        grid_x = int((x - self.map_origin_x) / self.map_resolution)
        grid_y = int((y - self.map_origin_y) / self.map_resolution)
        
        if (0 <= grid_x < self.inflated_grid.shape[1] and
            0 <= grid_y < self.inflated_grid.shape[0]):
            return bool(self.inflated_grid[grid_y, grid_x])
        
        return True  # 超出地图认为碰撞
    
    def world_to_grid(self, x, y):
        """世界坐标转栅格坐标
        
        参数：
            x, y (float): 世界坐标
        
        返回：
            tuple: (grid_x, grid_y) 栅格坐标
        """
        grid_x = int((x - self.map_origin_x) / self.map_resolution)
        grid_y = int((y - self.map_origin_y) / self.map_resolution)
        return grid_x, grid_y
    
    def grid_to_world(self, grid_x, grid_y):
        """栅格坐标转世界坐标
        
        参数：
            grid_x, grid_y (int): 栅格坐标
        
        返回：
            tuple: (x, y) 世界坐标
        """
        x = grid_x * self.map_resolution + self.map_origin_x
        y = grid_y * self.map_resolution + self.map_origin_y
        return x, y
    
    def get_map_bounds(self):
        """获取地图边界
        
        返回：
            dict: {'x_min', 'x_max', 'y_min', 'y_max'}
        """
        if self.map_data is None:
            return None
        
        h, w = self.map_data.shape
        return {
            'x_min': self.map_origin_x,
            'x_max': self.map_origin_x + w * self.map_resolution,
            'y_min': self.map_origin_y,
            'y_max': self.map_origin_y + h * self.map_resolution
        }
    
    def get_map_copy(self):
        """获取地图数据副本（线程安全）"""
        with self.map_lock:
            if self.cost_map is None:
                return None
            return self.cost_map.copy()


def main(args=None):
    rclpy.init(args=args)
    handler = SlamMapHandler()
    rclpy.spin(handler)
    handler.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
