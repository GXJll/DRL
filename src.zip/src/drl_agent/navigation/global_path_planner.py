#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全局路径规划模块
使用A*算法在栅格地图上规划全局路径
"""

import numpy as np
from heapq import heappush, heappop
from math import sqrt, hypot
import time


class GlobalPathPlanner:
    """A*全局路径规划器
    
    作用：
    1. 在SLAM生成的栅格地图上规划路径
    2. 使用A*算法保��最优性
    3. 支持8方向移动
    4. 处理不可达情况
    """
    
    def __init__(self, slam_map_handler):
        """
        参数：
            slam_map_handler: SlamMapHandler实例
        """
        self.slam_handler = slam_map_handler
        
        # A*参数
        self.diagonal_cost = sqrt(2)  # 对角线移动成本
        self.straight_cost = 1.0      # 直线移动成本
        
        # 8方向移动向量 (x, y, cost)
        self.directions = [
            (1, 0, self.straight_cost),      # 右
            (-1, 0, self.straight_cost),     # 左
            (0, 1, self.straight_cost),      # 上
            (0, -1, self.straight_cost),     # 下
            (1, 1, self.diagonal_cost),      # 右上
            (1, -1, self.diagonal_cost),     # 右下
            (-1, 1, self.diagonal_cost),     # 左上
            (-1, -1, self.diagonal_cost),    # 左下
        ]
    
    def plan_path(self, start_x, start_y, goal_x, goal_y, max_time=5.0):
        """规划从start到goal的路径
        
        参数：
            start_x, start_y (float): 起点世界坐标
            goal_x, goal_y (float): 目标世界坐标
            max_time (float): 最大规划时间(秒)
        
        返回：
            list: 路径点列表 [(x1,y1), (x2,y2), ...] 或 None
        """
        start_time = time.time()
        
        # ==================== 1. 坐标转换 ====================
        cost_map = self.slam_handler.get_map_copy()
        if cost_map is None:
            return None
        
        start_grid = self.slam_handler.world_to_grid(start_x, start_y)
        goal_grid = self.slam_handler.world_to_grid(goal_x, goal_y)
        
        # 检查起点和目标点
        if self._is_invalid(start_grid, cost_map):
            print(f"[ERROR] Start position is invalid: {start_grid}")
            return None
        
        if self._is_invalid(goal_grid, cost_map):
            print(f"[ERROR] Goal position is invalid: {goal_grid}")
            return None
        
        # ==================== 2. A*搜索 ====================
        open_set = []  # 优先队列: (f_score, counter, node)
        counter = 0
        
        # (g_score, h_score)字典
        g_score = {start_grid: 0}
        h_score = {start_grid: self._heuristic(start_grid, goal_grid)}
        f_score = {start_grid: h_score[start_grid]}
        
        # 记录父节点用于重建路径
        came_from = {}
        
        # 已关闭集合
        closed_set = set()
        
        heappush(open_set, (f_score[start_grid], counter, start_grid))
        counter += 1
        
        # A*主循环
        while open_set:
            # 检查超时
            if time.time() - start_time > max_time:
                print("[WARNING] Path planning timeout")
                return None
            
            # 弹出f值最小的节点
            _, _, current = heappop(open_set)
            
            if current == goal_grid:
                # 找到路径，重建路径
                path = self._reconstruct_path(came_from, current)
                path = self._world_path(path)
                
                elapsed_time = time.time() - start_time
                print(f"[SUCCESS] Path found in {elapsed_time:.3f}s, "
                      f"length: {len(path)} points")
                return path
            
            closed_set.add(current)
            
            # 探索邻居
            for dx, dy, move_cost in self.directions:
                neighbor = (current[0] + dx, current[1] + dy)
                
                # 跳过已关闭节点
                if neighbor in closed_set:
                    continue
                
                # 检查邻居有效性
                if self._is_invalid(neighbor, cost_map):
                    continue
                
                # 计算g值
                tentative_g = g_score[current] + move_cost
                
                # 如果已访问且新路径不更优，跳过
                if neighbor in g_score and tentative_g >= g_score[neighbor]:
                    continue
                
                # 记录更优路径
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                h_score[neighbor] = self._heuristic(neighbor, goal_grid)
                f_score[neighbor] = tentative_g + h_score[neighbor]
                
                heappush(open_set, (f_score[neighbor], counter, neighbor))
                counter += 1
        
        # 未找到路径
        print("[WARNING] No path found")
        return None
    
    def _is_invalid(self, grid_pos, cost_map):
        """检查栅格位置是否有效
        
        参数：
            grid_pos (tuple): (grid_x, grid_y)
            cost_map: 成本地图
        
        返回：
            bool: True表示无效（障碍物或超出边界）
        """
        x, y = grid_pos
        h, w = cost_map.shape
        
        # 边界检查
        if x < 0 or x >= w or y < 0 or y >= h:
            return True
        
        # 成本检查（成本>0.5认为是障碍物）
        return cost_map[y, x] > 0.5
    
    def _heuristic(self, pos, goal):
        """启发式函数（欧几里得距离）
        
        参数：
            pos, goal (tuple): 栅格坐标
        
        返回：
            float: 估计成本
        """
        dx = abs(pos[0] - goal[0])
        dy = abs(pos[1] - goal[1])
        
        # 对角线距离启发式
        return hypot(dx, dy)
    
    def _reconstruct_path(self, came_from, current):
        """从记录的父节点重建路径
        
        参数：
            came_from (dict): 父节点字典
            current (tuple): 当前节点
        
        返回：
            list: 路径点列表（栅格坐标）
        """
        path = [current]
        
        while current in came_from:
            current = came_from[current]
            path.append(current)
        
        path.reverse()
        return path
    
    def _world_path(self, grid_path):
        """将栅格坐标路径转换为世界坐标
        
        参数：
            grid_path (list): 栅格坐标路径
        
        返回：
            list: 世界坐标路径 [(x1,y1), ...]
        """
        world_path = []
        for gx, gy in grid_path:
            x, y = self.slam_handler.grid_to_world(gx, gy)
            world_path.append((x, y))
        
        return world_path
    
    def smooth_path(self, path, max_iterations=100):
        """路径平滑处理（使用贪心法）
        
        参数：
            path (list): 原始路径点列表
            max_iterations (int): 最大迭代次数
        
        返回：
            list: 平滑后的路径
        """
        if len(path) <= 2:
            return path
        
        cost_map = self.slam_handler.get_map_copy()
        if cost_map is None:
            return path
        
        smoothed = [path[0]]  # 保留起点
        
        i = 0
        while i < len(path) - 1:
            # 尝试直接连接到更远的点
            j = len(path) - 1
            
            while j > i + 1:
                # 检查i到j之间是否有直线通过
                if self._line_collision_free(
                    path[i], path[j], cost_map
                ):
                    smoothed.append(path[j])
                    i = j
                    break
                j -= 1
            else:
                # 无法直接连接，添加下一个点
                smoothed.append(path[i + 1])
                i += 1
        
        smoothed.append(path[-1])  # 保留终点
        return smoothed
    
    def _line_collision_free(self, start, end, cost_map):
        """检查两点之间的直线是否无碰撞
        
        参数：
            start, end (tuple): 世界坐标
            cost_map: 成本地图
        
        返回：
            bool: True表示无碰撞
        """
        # Bresenham直线算法检查
        x1, y1 = self.slam_handler.world_to_grid(start[0], start[1])
        x2, y2 = self.slam_handler.world_to_grid(end[0], end[1])
        
        points = self._bresenham_line(x1, y1, x2, y2)
        
        for x, y in points:
            if self._is_invalid((x, y), cost_map):
                return False
        
        return True
    
    def _bresenham_line(self, x1, y1, x2, y2):
        """Bresenham直线算法"""
        points = []
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        sx = 1 if x2 > x1 else -1
        sy = 1 if y2 > y1 else -1
        err = dx - dy
        
        while True:
            points.append((x1, y1))
            
            if x1 == x2 and y1 == y2:
                break
            
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x1 += sx
            if e2 < dx:
                err += dx
                y1 += sy
        
        return points


# 示例使用
if __name__ == "__main__":
    # 需要配合slam_map_handler使用
    print("Global Path Planner Module Loaded")
