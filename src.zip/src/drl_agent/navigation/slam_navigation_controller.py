#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
独立的SLAM导航控制器 - 不与DRL训练冲突
可以独立运行，不需要依赖训练节点
"""

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from geometry_msgs.msg import Twist, PoseStamped
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from squaternion import Quaternion
import threading
from math import hypot, atan2, pi, sqrt
import scipy.ndimage as ndimage
from heapq import heappush, heappop
import time


class SlamMapHandler:
    """SLAM地图处理"""
    
    def __init__(self, node):
        self.node = node
        self.map_data = None
        self.cost_map = None
        self.inflated_grid = None
        self.map_resolution = 0.05
        self.map_origin_x = 0.0
        self.map_origin_y = 0.0
        self.inflation_radius = 0.15
        self.map_lock = threading.Lock()
        self.map_ready = False
        
        # 使用BEST_EFFORT以避免与其他订阅者冲突
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.map_sub = node.create_subscription(
            OccupancyGrid, "/map", self._map_callback, qos
        )
        node.get_logger().info("🗺️  SLAM地图处理器初始化")
    
    def _map_callback(self, msg):
        with self.map_lock:
            old_ready = self.map_ready
            
            self.map_info = msg.info
            self.map_resolution = msg.info.resolution
            self.map_origin_x = msg.info.origin.position.x
            self.map_origin_y = msg.info.origin.position.y
            
            self.map_data = np.array(
                msg.data, dtype=np.int8
            ).reshape((msg.info.height, msg.info.width))
            
            self._generate_cost_map()
            
            if not old_ready:
                self.map_ready = True
                self.node.get_logger().info(
                    f"✅ SLAM地图已准备就绪"
                )
    
    def _generate_cost_map(self):
        if self.map_data is None:
            return
        
        occupied = self.map_data > 50
        inflation_cells = max(1, int(np.ceil(self.inflation_radius / self.map_resolution)))
        inflated = ndimage.maximum_filter(
            occupied.astype(np.uint8),
            size=2 * inflation_cells + 1
        )
        self.inflated_grid = inflated
        distance = ndimage.distance_transform_edt(1 - inflated) * self.map_resolution
        self.cost_map = np.exp(-distance / max(self.inflation_radius, 0.1))
    
    def world_to_grid(self, x, y):
        grid_x = int(round((x - self.map_origin_x) / self.map_resolution))
        grid_y = int(round((y - self.map_origin_y) / self.map_resolution))
        return grid_x, grid_y
    
    def grid_to_world(self, grid_x, grid_y):
        x = grid_x * self.map_resolution + self.map_origin_x
        y = grid_y * self.map_resolution + self.map_origin_y
        return x, y
    
    def is_in_bounds(self, grid_x, grid_y):
        if self.cost_map is None:
            return False
        h, w = self.cost_map.shape
        return 0 <= grid_x < w and 0 <= grid_y < h
    
    def get_cost_map_copy(self):
        with self.map_lock:
            if self.cost_map is None:
                return None
            return self.cost_map.copy()


class GlobalPathPlanner:
    """A*全局规划"""
    
    def __init__(self, slam_handler, node):
        self.slam = slam_handler
        self.node = node
        self.directions = [
            (1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
            (1, 1, sqrt(2)), (1, -1, sqrt(2)), (-1, 1, sqrt(2)), (-1, -1, sqrt(2))
        ]
    
    def plan_path(self, start_x, start_y, goal_x, goal_y, max_time=5.0):
        start_time = time.time()
        
        if not self.slam.map_ready:
            return None
        
        cost_map = self.slam.get_cost_map_copy()
        if cost_map is None:
            return None
        
        start_grid = self.slam.world_to_grid(start_x, start_y)
        goal_grid = self.slam.world_to_grid(goal_x, goal_y)
        
        if not self.slam.is_in_bounds(start_grid[0], start_grid[1]):
            return None
        
        if self._is_collision(goal_grid, cost_map):
            return None
        
        search_start = self._find_nearest_free_cell(start_grid, cost_map)
        if search_start is None:
            return None
        
        open_set = []
        g_score = {search_start: 0}
        h_score = {search_start: self._heuristic(search_start, goal_grid)}
        f_score = {search_start: h_score[search_start]}
        came_from = {}
        closed_set = set()
        counter = 0
        
        heappush(open_set, (f_score[search_start], counter, search_start))
        counter += 1
        
        while open_set:
            if time.time() - start_time > max_time:
                return None
            
            _, _, current = heappop(open_set)
            
            if current == goal_grid:
                path = self._reconstruct_path(came_from, current, search_start)
                return self._world_path(path)
            
            closed_set.add(current)
            
            for dx, dy, move_cost in self.directions:
                neighbor = (current[0] + dx, current[1] + dy)
                
                if neighbor in closed_set or self._is_collision(neighbor, cost_map):
                    continue
                
                tentative_g = g_score[current] + move_cost
                
                if neighbor in g_score and tentative_g >= g_score[neighbor]:
                    continue
                
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                h_score[neighbor] = self._heuristic(neighbor, goal_grid)
                f_score[neighbor] = tentative_g + h_score[neighbor]
                
                heappush(open_set, (f_score[neighbor], counter, neighbor))
                counter += 1
        
        return None
    
    def _find_nearest_free_cell(self, grid_pos, cost_map, max_radius=10):
        x, y = grid_pos
        if not self._is_collision((x, y), cost_map):
            return grid_pos
        
        for radius in range(1, max_radius + 1):
            for dx in range(-radius, radius + 1):
                for dy in range(-radius, radius + 1):
                    if abs(dx) != radius and abs(dy) != radius:
                        continue
                    nx, ny = x + dx, y + dy
                    if self.slam.is_in_bounds(nx, ny) and not self._is_collision((nx, ny), cost_map):
                        return (nx, ny)
        return None
    
    def _is_collision(self, grid_pos, cost_map):
        x, y = grid_pos
        h, w = cost_map.shape
        return x < 0 or x >= w or y < 0 or y >= h or cost_map[y, x] > 0.5
    
    def _heuristic(self, pos, goal):
        return hypot(abs(pos[0] - goal[0]), abs(pos[1] - goal[1]))
    
    def _reconstruct_path(self, came_from, current, start):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        if path[0] != start:
            path.insert(0, start)
        return path
    
    def _world_path(self, grid_path):
        return [self.slam.grid_to_world(gx, gy) for gx, gy in grid_path]


class LocalPathPlanner:
    """局部规划"""
    
    def __init__(self, slam_handler):
        self.slam = slam_handler
    
    def calculate_velocity(self, current_pose, next_waypoint):
        x, y, theta = current_pose
        goal_x, goal_y = next_waypoint
        
        goal_angle = atan2(goal_y - y, goal_x - x)
        angle_diff = goal_angle - theta
        
        while angle_diff > pi:
            angle_diff -= 2 * pi
        while angle_diff < -pi:
            angle_diff += 2 * pi
        
        dist = hypot(goal_x - x, goal_y - y)
        
        if dist < 0.5:
            linear_v = min(0.15, dist * 0.2)
        else:
            linear_v = 0.2
        
        if abs(angle_diff) > 0.3:
            linear_v *= 0.5
            angular_w = min(max(angle_diff * 1.0, -0.8), 0.8)
        else:
            angular_w = min(max(angle_diff * 0.5, -0.5), 0.5)
        
        return linear_v, angular_w


class SlamNavigationStandalone(Node):
    """独立的SLAM导航���制器 - 不与DRL训练冲突"""
    
    def __init__(self):
        super().__init__("slam_navigation_standalone")
        
        self.get_logger().info("\n" + "="*70)
        self.get_logger().info("🚀 独立SLAM导航控制器启动")
        self.get_logger().info("   (不依赖DRL训练代码)")
        self.get_logger().info("="*70 + "\n")
        
        self.slam_handler = SlamMapHandler(self)
        self.global_planner = GlobalPathPlanner(self.slam_handler, self)
        self.local_planner = LocalPathPlanner(self.slam_handler)
        
        self.current_pose = np.array([0.0, 0.0, 0.0])
        self.goal_pose = None
        self.global_path = None
        self.is_navigating = False
        self.pose_lock = threading.Lock()
        self.nav_lock = threading.Lock()
        
        self.odom_count = 0
        self.last_cmd_v = 0.0
        self.last_cmd_w = 0.0
        
        # ✅ 关键：使用BEST_EFFORT QoS避免冲突
        qos_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )
        
        qos_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        cb_group = MutuallyExclusiveCallbackGroup()
        
        # 订阅里程计 - 使用BEST_EFFORT
        self.odom_sub = self.create_subscription(
            Odometry, "/odom", self._odom_callback, 
            qos_best_effort, callback_group=cb_group
        )
        
        # 订阅目标
        self.goal_sub = self.create_subscription(
            PoseStamped, "/slam_goal", self._goal_callback, 
            qos_reliable, callback_group=cb_group
        )
        
        # 发布速度 - 使用BEST_EFFORT
        self.cmd_vel_pub = self.create_publisher(Twist, "/slam_cmd_vel", qos_best_effort)
        self.path_pub = self.create_publisher(Path, "/slam_path", qos_best_effort)
        
        # 定时器
        self.create_timer(2.0, self._planning_callback)
        self.create_timer(0.05, self._control_callback)
        self.create_timer(1.0, self._debug_callback)
        
        self.get_logger().info("✅ 导航系统就绪\n")
    
    def _odom_callback(self, msg):
        """里程计回调"""
        self.odom_count += 1
        
        if self.odom_count == 1:
            self.get_logger().info("✅ 里程计已连接！")
        
        with self.pose_lock:
            self.current_pose[0] = msg.pose.pose.position.x
            self.current_pose[1] = msg.pose.pose.position.y
            
            q = msg.pose.pose.orientation
            quat = Quaternion(q.w, q.x, q.y, q.z)
            _, _, self.current_pose[2] = quat.to_euler()
    
    def _goal_callback(self, msg):
        """目标回调"""
        goal_x = msg.pose.position.x
        goal_y = msg.pose.position.y
        
        with self.pose_lock:
            curr_x, curr_y, _ = self.current_pose
        
        dist = hypot(goal_x - curr_x, goal_y - curr_y)
        
        self.get_logger().info("\n" + "="*70)
        self.get_logger().info(f"🎯 新导航目标")
        self.get_logger().info(f"   位置: ({goal_x:.3f}, {goal_y:.3f})")
        self.get_logger().info(f"   距离: {dist:.3f}m")
        self.get_logger().info("="*70 + "\n")
        
        with self.nav_lock:
            self.goal_pose = (goal_x, goal_y)
            self.global_path = None
            self.is_navigating = True
    
    def _planning_callback(self):
        """全局路径规划"""
        if not self.is_navigating or self.goal_pose is None or self.odom_count == 0:
            return
        
        with self.pose_lock:
            x, y, theta = self.current_pose.copy()
        
        with self.nav_lock:
            goal_x, goal_y = self.goal_pose
            
            if self.global_path is not None:
                return
        
        dist = hypot(goal_x - x, goal_y - y)
        
        if dist < 0.3:
            self.get_logger().info("✅ 目标已到达！\n")
            self.is_navigating = False
            self._send_velocity(0.0, 0.0)
            return
        
        self.get_logger().info(f"📍 规划路径...")
        path = self.global_planner.plan_path(x, y, goal_x, goal_y)
        
        if path is not None:
            with self.nav_lock:
                self.global_path = path
            self._publish_path(path)
    
    def _control_callback(self):
        """控制循环"""
        if not self.is_navigating or self.odom_count == 0:
            self._send_velocity(0.0, 0.0)
            return
        
        with self.nav_lock:
            path = self.global_path
        
        if path is None or len(path) < 2:
            self._send_velocity(0.0, 0.0)
            return
        
        with self.pose_lock:
            current_pose = tuple(self.current_pose)
        
        # 找前看点
        next_waypoint = None
        for wp in path:
            dist_to_wp = hypot(wp[0] - current_pose[0], wp[1] - current_pose[1])
            if dist_to_wp > 0.2:
                next_waypoint = wp
                break
        
        if next_waypoint is None:
            next_waypoint = path[-1]
        
        linear_v, angular_w = self.local_planner.calculate_velocity(
            current_pose, next_waypoint
        )
        
        self._send_velocity(linear_v, angular_w)
        self.last_cmd_v = linear_v
        self.last_cmd_w = angular_w
    
    def _debug_callback(self):
        """调试信息"""
        if self.is_navigating and self.odom_count > 0:
            self.get_logger().info(
                f"📊 v={self.last_cmd_v:.3f}m/s | w={self.last_cmd_w:.3f}rad/s | "
                f"pos=({self.current_pose[0]:.3f}, {self.current_pose[1]:.3f})"
            )
    
    def _send_velocity(self, linear_v, angular_w):
        msg = Twist()
        msg.linear.x = float(linear_v)
        msg.angular.z = float(angular_w)
        self.cmd_vel_pub.publish(msg)
    
    def _publish_path(self, path):
        msg = Path()
        msg.header.frame_id = "map"
        msg.header.stamp = self.get_clock().now().to_msg()
        
        for x, y in path:
            pose = PoseStamped()
            pose.header = msg.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.orientation.w = 1.0
            msg.poses.append(pose)
        
        self.path_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = SlamNavigationStandalone()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    executor.spin()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
