#include "nav2_mpc_planner/mpc_planner.hpp"
#include "nav2_util/node_utils.hpp"

namespace nav2_mpc_planner
{

void MPCPlanner::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string name,
  std::shared_ptr<tf2_ros::Buffer> tf,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  node_ = parent.lock();
  name_ = name;
  tf_ = tf;
  costmap_ros_ = costmap_ros;

  // 加载参数
  nav2_util::declare_parameter_if_not_declared(node_, name_ + ".max_vel_x", rclcpp::ParameterValue(0.26));
  nav2_util::declare_parameter_if_not_declared(node_, name_ + ".max_vel_theta", rclcpp::ParameterValue(1.0));
  nav2_util::declare_parameter_if_not_declared(node_, name_ + ".xy_goal_tolerance", rclcpp::ParameterValue(0.25));
  nav2_util::declare_parameter_if_not_declared(node_, name_ + ".yaw_goal_tolerance", rclcpp::ParameterValue(0.25));
  
  node_->get_parameter(name_ + ".max_vel_x", max_vx_);
  node_->get_parameter(name_ + ".max_vel_theta", max_vth_);
  node_->get_parameter(name_ + ".xy_goal_tolerance", xy_tol_);
  node_->get_parameter(name_ + ".yaw_goal_tolerance", yaw_tol_);
}

void MPCPlanner::cleanup() {}
void MPCPlanner::activate() { is_goal_reached_ = false; }
void MPCPlanner::deactivate() {}

void MPCPlanner::setPlan(const nav_msgs::msg::Path & path)
{
  global_path_ = path;
  is_goal_reached_ = false;
}

void MPCPlanner::setSpeedLimit(const double & speed_limit, const bool & percentage)
{
  (void)speed_limit;
  (void)percentage;
}

Eigen::Vector3d MPCPlanner::model(const Eigen::Vector3d & x, const Eigen::Vector2d & u, double dt)
{
  Eigen::Vector3d x_new = x;
  x_new(0) += u(0) * cos(x(2)) * dt;
  x_new(1) += u(0) * sin(x(2)) * dt;
  x_new(2) += u(1) * dt;
  return x_new;
}

Eigen::Vector2d MPCPlanner::solveMPC(const Eigen::Vector3d & curr_pose, const std::vector<Eigen::Vector3d> & ref_path)
{
  Eigen::Vector2d u = Eigen::Vector2d::Zero();
  if (ref_path.empty()) return u;

  // 计算跟踪误差
  Eigen::Vector3d error = ref_path[0] - curr_pose;
  error(2) = atan2(sin(error(2)), cos(error(2))); // 归一化偏航误差

  // 简化MPC（比例控制）
  double linear_vel = 0.5 * sqrt(error(0)*error(0) + error(1)*error(1));
  double angular_vel = 1.0 * error(2);

  // 速度限制
  linear_vel = std::clamp(linear_vel, 0.0, max_vx_);
  angular_vel = std::clamp(angular_vel, -max_vth_, max_vth_);

  // 到达目标点停止
  if (sqrt(error(0)*error(0) + error(1)*error(1)) < xy_tol_ && fabs(error(2)) < yaw_tol_) {
    linear_vel = 0.0;
    angular_vel = 0.0;
    is_goal_reached_ = true;
  }

  u(0) = linear_vel;
  u(1) = angular_vel;
  return u;
}

geometry_msgs::msg::TwistStamped MPCPlanner::computeVelocityCommands(
  const geometry_msgs::msg::PoseStamped & curr_pose,
  const geometry_msgs::msg::Twist & curr_vel,
  nav2_core::GoalChecker * goal_checker)
{
  (void)curr_vel;
  (void)goal_checker;

  geometry_msgs::msg::TwistStamped cmd_vel;
  cmd_vel.header = curr_pose.header;

  // 转换当前位姿到Eigen
  Eigen::Vector3d curr_eigen(
    curr_pose.pose.position.x,
    curr_pose.pose.position.y,
    get_yaw(curr_pose.pose.orientation));

  // 转换参考路径到Eigen
  std::vector<Eigen::Vector3d> ref_path;
  for (const auto & pose : global_path_.poses) {
    ref_path.push_back(Eigen::Vector3d(
      pose.pose.position.x,
      pose.pose.position.y,
      get_yaw(pose.pose.orientation)));
  }

  // 求解MPC并生成控制指令
  Eigen::Vector2d u = solveMPC(curr_eigen, ref_path);
  cmd_vel.twist.linear.x = u(0);
  cmd_vel.twist.angular.z = u(1);

  return cmd_vel;
}

}  // namespace nav2_mpc_planner

// 注册插件（Humble版本标准）
#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(nav2_mpc_planner::MPCPlanner, nav2_core::Controller)

