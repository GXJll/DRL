#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    robot_name_in_model = 'fishbot'
    package_name = 'gazebo_modele'
    urdf_name = "model.urdf"

    pkg_share = FindPackageShare(package=package_name).find(package_name)
    urdf_model_path = os.path.join(pkg_share, 'urdf', urdf_name)
    gazebo_world_path = os.path.join(pkg_share, 'world/3d.world')

    # 启动 Gazebo
    start_gazebo_cmd = ExecuteProcess(
        cmd=['gazebo', '--verbose',
             '-s', 'libgazebo_ros_init.so',
             '-s', 'libgazebo_ros_factory.so',
             gazebo_world_path],
        output='screen')

    # 机器人状态发布
    start_robot_state_publisher_cmd = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        arguments=[urdf_model_path],
        parameters=[{'use_sim_time': True}]
    )

    # 延迟 4 秒再生成机器人（关键！）
    spawn_entity_cmd = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', robot_name_in_model,
                   '-file', urdf_model_path,
                   '-z', '0.3'],
        output='screen')

    delayed_spawn = TimerAction(period=4.0, actions=[spawn_entity_cmd])

    # TF 坐标
    fake_basel_cmd4 = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        output='screen',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_footprint'])

    fake_basel_cmd5 = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        output='screen',
        arguments=['0', '0', '0.1', '0', '0', '0', 'base_footprint', 'base_link'])

    fake_basel_cmd6 = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        output='screen',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom'])

    ld = LaunchDescription()
    ld.add_action(start_gazebo_cmd)
    ld.add_action(start_robot_state_publisher_cmd)
    ld.add_action(delayed_spawn)  # 使用延迟生成
    ld.add_action(fake_basel_cmd4)
    ld.add_action(fake_basel_cmd5)
    ld.add_action(fake_basel_cmd6)

    return ld

