#!/usr/bin/env python3
"""
诊断脚本 - 检查ROS通信链路
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import time


class DiagnosticsNode(Node):
    def __init__(self):
        super().__init__('diagnostics')
        
        # 订阅速度命令反馈
        self.cmd_vel_sub = self.create_subscription(
            Twist, '/cmd_vel', self._cmd_vel_callback, 1
        )
        
        # 订阅里程计
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self._odom_callback, 1
        )
        
        # 发布速度命令进行测试
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 1)
        
        self.last_cmd_time = None
        self.last_odom_time = None
        self.last_pos = (0, 0)
        self.cmd_count = 0
        self.odom_count = 0
        
        # 定时器
        self.create_timer(2.0, self._check_status)
        self.create_timer(0.5, self._send_test_command)
        
        self.get_logger().info("🔍 诊断系统启动\n")
    
    def _cmd_vel_callback(self, msg):
        self.cmd_count += 1
        self.last_cmd_time = time.time()
        self.get_logger().debug(f"✅ 收到速度命令: v={msg.linear.x:.3f}, w={msg.angular.z:.3f}")
    
    def _odom_callback(self, msg):
        self.odom_count += 1
        self.last_odom_time = time.time()
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        self.last_pos = (x, y)
    
    def _send_test_command(self):
        """发送测试速度命令"""
        msg = Twist()
        msg.linear.x = 0.3   # 直线运动
        msg.angular.z = 0.0
        self.cmd_vel_pub.publish(msg)
    
    def _check_status(self):
        print("\n" + "="*70)
        print("🔍 系统诊断报告")
        print("="*70)
        
        # 检查速度命令
        if self.last_cmd_time is None:
            print("❌ 速度命令话题: 未收到任何命令")
        else:
            time_since_cmd = time.time() - self.last_cmd_time
            print(f"✅ 速度命令话题: 运行正常 (已收{self.cmd_count}条)")
            print(f"   └─ 距离最后命令: {time_since_cmd:.2f}s")
        
        # 检查里程计
        if self.last_odom_time is None:
            print("❌ 里程计话题: 未收到任何数据")
        else:
            time_since_odom = time.time() - self.last_odom_time
            print(f"✅ 里程计话题: 运行正常 (已收{self.odom_count}条)")
            print(f"   └─ 当前位置: ({self.last_pos[0]:.3f}, {self.last_pos[1]:.3f})")
            print(f"   └─ 距离最后更新: {time_since_odom:.2f}s")
        
        print("\n📋 故障排查:")
        print("1️⃣  如果速度命令正常但小车不动 → 检查电机控制器连接")
        print("2️⃣  如果里程计不更新 → 检查编码器或gazebo")
        print("3️⃣  如果都正常但小车卡住 → 检查碰撞或路径规划问题")
        print("="*70 + "\n")


def main(args=None):
    rclpy.init(args=args)
    node = DiagnosticsNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
