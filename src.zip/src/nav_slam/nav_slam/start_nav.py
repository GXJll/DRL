#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MPC + 社会性优化 + PPO强化学习
- PPO算法：更稳定的策略梯度方法
- Actor-Critic架构
- Advantage估计
- 优势归一化
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped, Pose
from nav_msgs.msg import Odometry, Path
from sensor_msgs.msg import LaserScan
import math
import numpy as np
from scipy.optimize import minimize
from collections import deque
import os
from datetime import datetime
import json
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal


# ==================== PPO神经网络 ====================
class ActorNetwork(nn.Module):
    """Actor网络 - 输出策略"""
    
    def __init__(self, state_dim=3, action_dim=2, hidden_dim=128):
        super(ActorNetwork, self).__init__()
        
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim)
        )
        
        # 动作标准差（可学习）
        self.log_std = nn.Parameter(torch.zeros(action_dim))
    
    def forward(self, state):
        """前向传播"""
        mean = self.net(state)
        std = torch.exp(self.log_std)
        return mean, std
    
    def get_action_and_log_prob(self, state):
        """获取动作和对数概率"""
        mean, std = self.forward(state)
        
        # 从高斯分布采样
        dist = Normal(mean, std)
        action = dist.rsample()
        log_prob = dist.log_prob(action).sum(dim=-1)
        
        return action, log_prob


class CriticNetwork(nn.Module):
    """Critic网络 - 估计值函数"""
    
    def __init__(self, state_dim=3, hidden_dim=128):
        super(CriticNetwork, self).__init__()
        
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
    
    def forward(self, state):
        """前向传播 - 返回值估计"""
        return self.net(state)


# ==================== ROS2 Gazebo控制器 ====================
class GazeboControllerROS2:
    """ROS2版本的Gazebo控制器"""
    
    def __init__(self, node, robot_name="pioneer3dx"):
        self.node = node
        self.robot_name = robot_name
        
        try:
            from gazebo_msgs.srv import SetEntityState
            
            self.set_entity_state_client = node.create_client(
                SetEntityState, 
                '/gazebo/set_entity_state'
            )
            
            node.get_logger().info("📡 正在连接 /gazebo/set_entity_state 服务...")
            
            start_time = time.time()
            while not self.set_entity_state_client.wait_for_service(timeout_sec=0.5):
                elapsed = time.time() - start_time
                if elapsed > 10:
                    node.get_logger().warn("⚠️  Gazebo服务未找到")
                    self.set_entity_state_client = None
                    break
                node.get_logger().info(f"⏳ 等待Gazebo服务... ({elapsed:.1f}s)")
            
            if self.set_entity_state_client is not None:
                node.get_logger().info("✅ Gazebo SetEntityState服务已连接！")
            
        except ImportError:
            node.get_logger().error("❌ 无法导入gazebo_msgs")
            self.set_entity_state_client = None
    
    def reset_robot_pose(self, x, y, theta):
        """重置机器人位置"""
        
        if self.set_entity_state_client is None:
            return False
        
        try:
            from gazebo_msgs.srv import SetEntityState
            from gazebo_msgs.msg import EntityState
            
            request = SetEntityState.Request()
            entity_state = EntityState()
            entity_state.name = self.robot_name
            entity_state.pose = Pose()
            entity_state.pose.position.x = float(x)
            entity_state.pose.position.y = float(y)
            entity_state.pose.position.z = 0.0
            
            quat = self._euler_to_quaternion(0, 0, theta)
            entity_state.pose.orientation.x = quat[0]
            entity_state.pose.orientation.y = quat[1]
            entity_state.pose.orientation.z = quat[2]
            entity_state.pose.orientation.w = quat[3]
            
            entity_state.twist.linear.x = 0.0
            entity_state.twist.linear.y = 0.0
            entity_state.twist.linear.z = 0.0
            entity_state.twist.angular.x = 0.0
            entity_state.twist.angular.y = 0.0
            entity_state.twist.angular.z = 0.0
            
            entity_state.reference_frame = "world"
            request.entity_state = entity_state
            
            future = self.set_entity_state_client.call_async(request)
            
            start = time.time()
            while rclpy.ok():
                if future.done():
                    try:
                        response = future.result()
                        if response.success:
                            self.node.get_logger().info(
                                f"✅ 机器人已重置到 ({x:.2f}, {y:.2f})"
                            )
                            return True
                        else:
                            return False
                    except Exception as e:
                        self.node.get_logger().error(f"❌ 服务调用异常: {e}")
                        return False
                
                if time.time() - start > 5.0:
                    self.node.get_logger().error("❌ 重置超时")
                    return False
                
                time.sleep(0.01)
            
        except Exception as e:
            self.node.get_logger().error(f"❌ 重置异常: {e}")
            return False
    
    @staticmethod
    def _euler_to_quaternion(roll, pitch, yaw):
        """欧拉角转四元数"""
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy
        
        return [x, y, z, w]


# ==================== PPO算法 ====================
class PPOPolicy:
    """PPO策略 - 主要的强化学习算法"""
    
    def __init__(self, state_dim=3, action_dim=2, learning_rate=3e-4,
                 gamma=0.99, gae_lambda=0.95, clip_ratio=0.2, 
                 entropy_coeff=0.01, device='cpu'):
        
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.clip_ratio = clip_ratio
        self.entropy_coeff = entropy_coeff
        self.device = device
        
        # 创建网络
        self.actor = ActorNetwork(state_dim, action_dim).to(device)
        self.critic = CriticNetwork(state_dim).to(device)
        
        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=learning_rate)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=learning_rate)
        
        # 经验缓冲
        self.experience_buffer = {
            'states': [],
            'actions': [],
            'rewards': [],
            'values': [],
            'log_probs': [],
            'dones': [],
        }
        
        # 训练统计
        self.episode_count = 0
        self.training_steps = 0
        self.episode_rewards = deque(maxlen=100)
    
    def select_action(self, state):
        """选择动作"""
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            mean, std = self.actor(state_tensor)
            value = self.critic(state_tensor)
        
        # 从策略分布采样动作
        dist = Normal(mean, std)
        action = dist.rsample()
        log_prob = dist.log_prob(action).sum(dim=-1)
        
        action_np = action.cpu().numpy()[0]
        value_np = value.cpu().numpy()[0, 0]
        log_prob_np = log_prob.cpu().numpy()[0]
        
        return action_np, log_prob_np, value_np
    
    def store_transition(self, state, action, reward, value, log_prob, done):
        """存储转移"""
        self.experience_buffer['states'].append(state)
        self.experience_buffer['actions'].append(action)
        self.experience_buffer['rewards'].append(reward)
        self.experience_buffer['values'].append(value)
        self.experience_buffer['log_probs'].append(log_prob)
        self.experience_buffer['dones'].append(done)
    
    def compute_advantages(self, last_value):
        """计算优势函数（GAE）"""
        rewards = self.experience_buffer['rewards']
        values = self.experience_buffer['values'] + [last_value]
        dones = self.experience_buffer['dones']
        
        advantages = []
        gae = 0
        
        for t in reversed(range(len(rewards))):
            if t == len(rewards) - 1:
                next_value = last_value
            else:
                next_value = values[t + 1]
            
            done = dones[t]
            delta = rewards[t] + self.gamma * next_value * (1 - done) - values[t]
            gae = delta + self.gamma * self.gae_lambda * (1 - done) * gae
            advantages.insert(0, gae)
        
        advantages = np.array(advantages)
        # 优势归一化
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        return advantages, np.array(rewards) + np.array(advantages) + np.array(values[:-1])
    
    def update(self, num_epochs=3, batch_size=64):
        """PPO更新"""
        if len(self.experience_buffer['states']) == 0:
            return
        
        # 转换为张量
        states = torch.FloatTensor(np.array(self.experience_buffer['states'])).to(self.device)
        actions = torch.FloatTensor(np.array(self.experience_buffer['actions'])).to(self.device)
        old_log_probs = torch.FloatTensor(self.experience_buffer['log_probs']).to(self.device)
        
        # 计算优势
        last_state = states[-1]
        with torch.no_grad():
            last_value = self.critic(last_state.unsqueeze(0)).cpu().numpy()[0, 0]
        
        advantages, returns = self.compute_advantages(last_value)
        advantages = torch.FloatTensor(advantages).to(self.device)
        returns = torch.FloatTensor(returns).to(self.device)
        
        # 多轮更新
        for epoch in range(num_epochs):
            # Mini-batch更新
            indices = np.arange(len(states))
            np.random.shuffle(indices)
            
            for i in range(0, len(states), batch_size):
                batch_indices = indices[i:i + batch_size]
                
                batch_states = states[batch_indices]
                batch_actions = actions[batch_indices]
                batch_old_log_probs = old_log_probs[batch_indices]
                batch_advantages = advantages[batch_indices]
                batch_returns = returns[batch_indices]
                
                # Actor更新
                mean, std = self.actor(batch_states)
                dist = Normal(mean, std)
                new_log_probs = dist.log_prob(batch_actions).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1)
                
                # PPO损失
                ratio = torch.exp(new_log_probs - batch_old_log_probs)
                surr1 = ratio * batch_advantages
                surr2 = torch.clamp(ratio, 1 - self.clip_ratio, 1 + self.clip_ratio) * batch_advantages
                actor_loss = -torch.min(surr1, surr2).mean() - self.entropy_coeff * entropy.mean()
                
                self.actor_optimizer.zero_grad()
                actor_loss.backward()
                self.actor_optimizer.step()
                
                # Critic更新
                values = self.critic(batch_states).squeeze(-1)
                critic_loss = ((values - batch_returns) ** 2).mean()
                
                self.critic_optimizer.zero_grad()
                critic_loss.backward()
                self.critic_optimizer.step()
            
            self.training_steps += 1
    
    def clear_buffer(self):
        """清空缓冲"""
        for key in self.experience_buffer:
            self.experience_buffer[key] = []


# ==================== 碰撞检测器 ====================
class CollisionDetector:
    """高级碰撞检测"""
    
    def __init__(self, robot_radius=0.25, collision_threshold=0.15):
        self.robot_radius = robot_radius
        self.collision_threshold = collision_threshold
        self.collision_history = deque(maxlen=5)
    
    def check_collision(self, obstacles, robot_pose):
        """检测碰撞"""
        
        if len(obstacles) == 0:
            self.collision_history.append(False)
            return False, np.inf, None
        
        distances = np.linalg.norm(
            obstacles - robot_pose[:2],
            axis=1
        )
        
        min_distance = np.min(distances)
        closest_obstacle = obstacles[np.argmin(distances)]
        
        is_collision = min_distance < (self.robot_radius + self.collision_threshold)
        
        self.collision_history.append(is_collision)
        
        recent_collisions = sum(self.collision_history)
        
        return recent_collisions >= 2, min_distance, closest_obstacle


# ==================== 日志管理器 ====================
class PerformanceLogger:
    """性能日志管理器"""
    
    def __init__(self, log_dir="./mpc_logs"):
        self.log_dir = log_dir
        
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(log_dir, f"ppo_training_{timestamp}.txt")
        self.metrics_file = os.path.join(log_dir, f"ppo_metrics_{timestamp}.json")
        
        self.metrics = {
            'episode': [],
            'episode_reward': [],
            'episode_distance': [],
            'episode_steps': [],
            'collision_count': [],
            'success': [],
            'reset_count': [],
            'avg_reward': [],
        }
        
        self._write_header()
    
    def _write_header(self):
        with open(self.log_file, 'w', encoding='utf-8') as f:
            f.write("="*120 + "\n")
            f.write("MPC + 社会性优化 + PPO强化学习 训练日志\n")
            f.write("="*120 + "\n")
            f.write(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*120 + "\n\n")
    
    def log_episode(self, episode, reward, distance, steps, collision_count, 
                   success, reset_count):
        """记录单个episode"""
        
        self.metrics['episode'].append(episode)
        self.metrics['episode_reward'].append(reward)
        self.metrics['episode_distance'].append(distance)
        self.metrics['episode_steps'].append(steps)
        self.metrics['collision_count'].append(collision_count)
        self.metrics['success'].append(1 if success else 0)
        self.metrics['reset_count'].append(reset_count)
        self.metrics['avg_reward'].append(np.mean(self.metrics['episode_reward'][-100:]))
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*120}\n")
            f.write(f"Episode {episode:5d}\n")
            f.write(f"{'='*120}\n")
            f.write(f"总奖励:        {reward:10.4f}\n")
            f.write(f"移动距离:      {distance:10.4f} m\n")
            f.write(f"步数:          {steps:10d}\n")
            f.write(f"碰撞次数:      {collision_count:10d}\n")
            f.write(f"重置次数:      {reset_count:10d}\n")
            f.write(f"成功到达:      {'✅ 是' if success else '❌ 否'}\n")
            
            if len(self.metrics['episode_reward']) >= 10:
                last_10 = np.mean(self.metrics['episode_reward'][-10:])
                f.write(f"最后10集平均奖励: {last_10:10.4f}\n")
    
    def log_reset(self, reason, position):
        """记录重置事件"""
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f"  🔄 重置: {reason} at ({position[0]:.2f}, {position[1]:.2f})\n")
    
    def save_metrics(self):
        """保存JSON指标"""
        with open(self.metrics_file, 'w', encoding='utf-8') as f:
            json.dump(self.metrics, f, indent=2)


# ==================== MPC控制器 ====================
class AdaptiveMPCController:
    """自适应MPC"""
    
    def __init__(self, wheelbase=0.27, dt=0.05, horizon=10):
        self.wheelbase = wheelbase
        self.dt = dt
        self.horizon = horizon
        self.max_v = 0.8
        self.max_w = 1.2
        
        self.w_path = 8.0
        self.w_collision = 100.0
        self.w_smooth = 0.5
        self.w_encourage = 10.0
    
    def predict_trajectory(self, state, controls):
        """预测轨迹"""
        trajectory = [state.copy()]
        current_state = state.copy()
        
        for v, w in controls:
            x, y, theta = current_state
            
            dx = v * np.cos(theta)
            dy = v * np.sin(theta)
            dtheta = w
            
            current_state = np.array([
                x + dx * self.dt,
                y + dy * self.dt,
                theta + dtheta * self.dt
            ])
            
            current_state[2] = np.arctan2(
                np.sin(current_state[2]), 
                np.cos(current_state[2])
            )
            
            trajectory.append(current_state)
        
        return trajectory
    
    def calculate_objective(self, controls_flat, current_state, path, obstacles):
        """目标函数"""
        
        controls = controls_flat.reshape(self.horizon, 2)
        trajectory = self.predict_trajectory(current_state, controls)
        
        path_cost = 0.0
        for pred_state in trajectory:
            distances = np.linalg.norm(path - pred_state[:2], axis=1)
            min_dist = np.min(distances) if len(distances) > 0 else 0
            path_cost += min_dist ** 2
        
        collision_cost = 0.0
        for pred_state in trajectory:
            for obs in obstacles:
                dist = np.sqrt(
                    (pred_state[0] - obs[0])**2 + 
                    (pred_state[1] - obs[1])**2
                )
                if dist < 0.5:
                    collision_cost += (0.5 - dist) ** 2 * 100
        
        smooth_cost = 0.0
        for v, w in controls:
            smooth_cost += (v ** 2 + w ** 2) * 0.01
        
        motion_cost = 0.0
        for v, w in controls:
            if v > 0.1:
                motion_cost -= v
        
        total_cost = (self.w_path * path_cost +
                     self.w_collision * collision_cost +
                     self.w_smooth * smooth_cost +
                     self.w_encourage * motion_cost)
        
        return total_cost
    
    def compute_control(self, current_state, path, obstacles):
        """计算控制"""
        
        if len(path) < 2:
            return 0.0, 0.0
        
        initial_controls = np.array([0.3, 0.0] * self.horizon)
        
        bounds = []
        for _ in range(self.horizon):
            bounds.append((-self.max_v, self.max_v))
            bounds.append((-self.max_w, self.max_w))
        
        try:
            result = minimize(
                self.calculate_objective,
                initial_controls,
                args=(current_state, path, obstacles),
                method='SLSQP',
                bounds=bounds,
                options={'maxiter': 30}
            )
            
            optimal_controls = result.x.reshape(self.horizon, 2)
            v = optimal_controls[0, 0]
            w = optimal_controls[0, 1]
            
            if 0.05 < abs(v) < 0.1:
                v = np.sign(v) * 0.15
            
            return v, w
        except:
            return 0.3, 0.0


# ==================== 主ROS2节点 ====================
class MPCPPONode(Node):
    """MPC + PPO"""
    
    def __init__(self):
        super().__init__('mpc_ppo_training')
        
        self.get_logger().info("="*80)
        self.get_logger().info("🚀 MPC + 社会性优化 + PPO强化学习 ROS2版本启动")
        self.get_logger().info("="*80)
        
        # 检查GPU
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.get_logger().info(f"💻 使用设备: {self.device}")
        
        # 初始化组件
        self.logger = PerformanceLogger()
        self.mpc = AdaptiveMPCController()
        self.ppo_policy = PPOPolicy(
            state_dim=3,
            action_dim=2,
            learning_rate=3e-4,
            device=self.device
        )
        self.collision_detector = CollisionDetector()
        
        # Gazebo控制器
        try:
            self.gazebo_controller = GazeboControllerROS2(self, robot_name="pioneer3dx")
            self.gazebo_available = True
        except Exception as e:
            self.get_logger().warn(f"⚠️  Gazebo控制器初始化失败: {e}")
            self.gazebo_controller = None
            self.gazebo_available = False
        
        # 状态
        self.path = None
        self.obstacles = []
        self.current_pose = np.array([0.0, 0.0, 0.0])
        self.last_pose = np.array([0.0, 0.0, 0.0])
        
        # Episode统计
        self.episode_count = 0
        self.episode_reward = 0.0
        self.episode_distance = 0.0
        self.episode_steps = 0
        self.episode_collision_count = 0
        self.episode_reset_count = 0
        self.episode_start_pose = None
        self.max_episode_steps = 500
        
        self.success_history = deque(maxlen=20)
        
        # 订阅发布
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_cb, 10
        )
        self.path_sub = self.create_subscription(
            Path, '/path2', self.path_cb, 10
        )
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_cb, 10
        )
        
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.goal_pub = self.create_publisher(PoseStamped, '/goal_pose', 10)
        
        # 定时器
        self.create_timer(0.05, self.control_loop)
        self.create_timer(10.0, self.ppo_train)
        self.create_timer(15.0, self.generate_new_goal)
        
        self.get_logger().info("✅ PPO节点启动完成！")
        
        self.generate_new_goal()
    
    def path_cb(self, msg):
        if len(msg.poses) > 0:
            self.path = np.array([
                [p.pose.position.x, p.pose.position.y] for p in msg.poses
            ])
    
    def scan_cb(self, msg):
        obstacles = []
        for i, r in enumerate(msg.ranges):
            if not (np.isinf(r) or np.isnan(r)) and r < 10.0 and r > 0.1:
                angle = msg.angle_min + i * msg.angle_increment
                ox = self.current_pose[0] + r * np.cos(angle + self.current_pose[2])
                oy = self.current_pose[1] + r * np.sin(angle + self.current_pose[2])
                obstacles.append([ox, oy])
        
        self.obstacles = np.array(obstacles) if obstacles else np.array([]).reshape(0, 2)
    
    def quaternion_to_yaw(self, q):
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny, cosy)
    
    def odom_cb(self, msg):
        self.current_pose[0] = msg.pose.pose.position.x
        self.current_pose[1] = msg.pose.pose.position.y
        self.current_pose[2] = self.quaternion_to_yaw(msg.pose.pose.orientation)
    
    def control_loop(self):
        if self.path is None or len(self.path) < 2:
            return
        
        self.episode_steps += 1
        
        dist_to_goal = np.linalg.norm(self.current_pose[:2] - self.path[-1])
        
        # 碰撞检测
        is_collision, min_distance, _ = self.collision_detector.check_collision(
            self.obstacles, self.current_pose
        )
        
        if is_collision:
            self.episode_collision_count += 1
            self.get_logger().error(f"💥 碰撞！距离: {min_distance:.3f}m")
            
            if self.episode_collision_count > 3 and self.gazebo_available:
                self.get_logger().warn("🔄 重置机器人...")
                self._reset_robot("碰撞过多")
                self.episode_reset_count += 1
                
                if self.episode_reset_count > 5:
                    self._end_episode(success=False)
                    return
        
        if self.episode_steps >= self.max_episode_steps:
            self.get_logger().warn("⏱️  Episode超时")
            self._end_episode(success=False)
            return
        
        if dist_to_goal < 0.2:
            self.get_logger().info(f"✅ 成功！Episode {self.episode_count}")
            self._end_episode(success=True)
            return
        
        # 计算控制
        collision_risk = self._compute_collision_risk()
        start_dist = np.linalg.norm(self.path[0] - self.episode_start_pose[:2])
        progress_ratio = max(0, (start_dist - dist_to_goal) / max(start_dist, 0.1))
        
        # MPC控制
        mpc_v, mpc_w = self.mpc.compute_control(
            self.current_pose, self.path, self.obstacles
        )
        
        if collision_risk > 0.7:
            mpc_v *= 0.2
        elif collision_risk > 0.4:
            mpc_v *= 0.6
        
        # PPO选择动作
        action, log_prob, value = self.ppo_policy.select_action(self.current_pose)
        
        # 融合MPC和PPO（MPC作为基础，PPO作为调整）
        v = 0.7 * mpc_v + 0.3 * np.clip(action[0], -self.mpc.max_v, self.mpc.max_v)
        w = 0.7 * mpc_w + 0.3 * np.clip(action[1], -self.mpc.max_w, self.mpc.max_w)
        
        # 计算奖励
        distance_moved = np.linalg.norm(self.current_pose[:2] - self.last_pose[:2])
        
        reward = 0.0
        if abs(v) > 0.1:
            reward += 1.0
        reward += distance_moved * 5.0
        reward += (1.0 - progress_ratio) * 1.0
        
        if abs(w) < 0.3:
            reward += 0.5
        
        if is_collision:
            reward -= 50.0
        elif collision_risk > 0.7:
            reward -= 5.0
        elif collision_risk > 0.5:
            reward -= 2.0
        
        if dist_to_goal < 0.2:
            reward += 50.0
        
        reward = np.clip(reward, -100.0, 50.0)
        
        # 存储转移
        self.ppo_policy.store_transition(
            self.current_pose, action, reward, value, log_prob, False
        )
        
        self.episode_reward += reward
        self.episode_distance += distance_moved
        
        # 发布命令
        cmd = Twist()
        cmd.linear.x = float(v)
        cmd.angular.z = float(w)
        self.cmd_pub.publish(cmd)
        
        if self.episode_steps % 50 == 0:
            success_rate = sum(self.success_history) / max(len(self.success_history), 1)
            self.get_logger().info(
                f"Episode {self.episode_count:4d} | Step {self.episode_steps:3d} | "
                f"PPO Reward {self.episode_reward:+.1f} | Dist {dist_to_goal:.2f}m | "
                f"Success {success_rate:.1%}"
            )
        
        self.last_pose = self.current_pose.copy()
    
    def _reset_robot(self, reason):
        """重置机器人"""
        if not self.gazebo_available or self.gazebo_controller is None:
            self.get_logger().warn("❌ Gazebo重置不可用")
            return
        
        stop_cmd = Twist()
        self.cmd_pub.publish(stop_cmd)
        
        success = self.gazebo_controller.reset_robot_pose(
            self.episode_start_pose[0],
            self.episode_start_pose[1],
            self.episode_start_pose[2]
        )
        
        if success:
            self.current_pose = self.episode_start_pose.copy()
            self.last_pose = self.episode_start_pose.copy()
            self.episode_collision_count = 0
            self.logger.log_reset(reason, self.episode_start_pose)
    
    def _end_episode(self, success):
        """结束episode"""
        
        # 计算最后的值估计
        last_value = 0.0 if success else -10.0
        
        # 存储最后转移
        self.ppo_policy.store_transition(
            self.current_pose, np.zeros(2), 0.0, last_value, 0.0, True
        )
        
        # 记录
        self.logger.log_episode(
            self.episode_count, self.episode_reward, self.episode_distance,
            self.episode_steps, self.episode_collision_count,
            success, self.episode_reset_count,
        )
        
        self.success_history.append(1 if success else 0)
        
        self.episode_count += 1
        self.ppo_policy.episode_count = self.episode_count
        self.episode_reward = 0.0
        self.episode_distance = 0.0
        self.episode_steps = 0
        self.episode_collision_count = 0
        self.episode_reset_count = 0
        
        self.generate_new_goal()
    
    def generate_new_goal(self):
        """生成新目标"""
        difficulty = min(1.0, self.episode_count / 100.0)
        max_distance = 2.0 + difficulty * 3.0
        
        angle = np.random.uniform(0, 2 * np.pi)
        distance = np.random.uniform(0.5, max_distance)
        
        goal_x = self.current_pose[0] + distance * np.cos(angle)
        goal_y = self.current_pose[1] + distance * np.sin(angle)
        
        goal_msg = PoseStamped()
        goal_msg.header.frame_id = "map"
        goal_msg.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.position.x = float(goal_x)
        goal_msg.pose.position.y = float(goal_y)
        goal_msg.pose.orientation.w = 1.0
        
        self.goal_pub.publish(goal_msg)
        self.episode_start_pose = self.current_pose.copy()
        
        self.get_logger().info(
            f"\n🎯 Episode {self.episode_count}: 目标 ({goal_x:.2f}, {goal_y:.2f})"
        )
    
    def _compute_collision_risk(self):
        """计算碰撞风险"""
        if len(self.obstacles) == 0:
            return 0.0
        
        min_dist = np.min(np.linalg.norm(
            self.obstacles - self.current_pose[:2], axis=1
        ))
        
        if min_dist < 0.2:
            return 1.0
        elif min_dist < 0.5:
            return min_dist / 0.5
        else:
            return 0.0
    
    def ppo_train(self):
        """PPO训练"""
        if len(self.ppo_policy.experience_buffer['states']) > 0:
            self.ppo_policy.update(num_epochs=3, batch_size=32)
            self.ppo_policy.clear_buffer()
            
            self.logger.save_metrics()
            
            avg_reward = np.mean(self.logger.metrics['episode_reward'][-10:]) if len(self.logger.metrics['episode_reward']) >= 10 else 0
            
            self.get_logger().info(
                f"🧠 PPO训练 | Episodes: {self.episode_count} | "
                f"Steps: {self.ppo_policy.training_steps} | "
                f"Avg_reward(10): {avg_reward:+.2f}"
            )


def main(args=None):
    rclpy.init(args=args)
    node = MPCPPONode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("训练完成")
        node.logger.save_metrics()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
