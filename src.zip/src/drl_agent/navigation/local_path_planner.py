#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
局部路径规划模块
使用DWA (Dynamic Window Approach) 进行动态避障
"""

import numpy as np
from math import cos, sin, sqrt


class LocalPathPlanner:
    """DWA动态窗口法局部规划器
    
    作用：
    1. 在全局路径规划的基础上进行局部避障
    2. 实时响应动态障碍物
    3. 生成可执行的速度命令
    """
    
    def __init__(self, slam_map_handler):
        """
        参数：
            slam_map_handler: SlamMapHandler实例
        """
        self.slam_handler = slam_map_handler
        
        # ==================== 机器人参数 ====================
        self.max_linear_velocity = 0.5      # m/s
        self.max_angular_velocity = 1.0    # rad/s
        self.min_linear_velocity = 0.0     # m/s
        self.min_angular_velocity = -1.0   # rad/s
        
        # ==================== 加速度限制 ====================
        self.max_linear_accel = 0.5        # m/s^2
        self.max_angular_accel = 1.0       # rad/s^2
        
        # ==================== DWA参数 ====================
        self.prediction_time = 0.5         # 预测时间(s)
        self.velocity_resolution = 0.1     # 速度分辨率
        self.angular_resolution = 0.1      # 角速度分辨率
        self.ob_dist_threshold = 0.5       # 障碍物检测阈值(m)
        
        # ==================== 权重参数 ====================
        self.heading_weight = 0.15         # 方向偏差权重
        self.distance_weight = 0.1         # 距离权重
        self.velocity_weight = 0.75        # 速度权重
    
    def calculate_velocity(self, current_pose, goal_pose, current_vel):
        """计算最优速度命令
        
        参数：
            current_pose (tuple): 当前位置 (x, y, theta)
            goal_pose (tuple): 目标位置 (x, y)
            current_vel (tuple): 当前速度 (v, w)
        
        返回：
            tuple: 最优速度 (linear_v, angular_w)
        """
        x, y, theta = current_pose
        goal_x, goal_y = goal_pose
        v, w = current_vel
        
        # ==================== 1. 计算动态窗口 ====================
        dw = self._calc_dynamic_window(v, w)
        
        # ==================== 2. 评估所有可能的速度组合 ====================
        best_score = -np.inf
        best_vel = (0, 0)
        
        for lin_v in np.arange(dw[0], dw[1], self.velocity_resolution):
            for ang_w in np.arange(dw[2], dw[3], self.angular_resolution):
                # 预测轨迹
                trajectory = self._predict_trajectory(
                    x, y, theta, lin_v, ang_w
                )
                
                # 计算评分
                score = self._evaluate_trajectory(
                    trajectory, goal_pose, lin_v
                )
                
                if score > best_score:
                    best_score = score
                    best_vel = (lin_v, ang_w)
        
        return best_vel
    
    def _calc_dynamic_window(self, current_v, current_w):
        """计算动态窗口
        
        考虑当前速度和加速度限制，计算可达速度范围
        
        参数：
            current_v (float): 当前线速度
            current_w (float): 当前角速度
        
        返回：
            tuple: (v_min, v_max, w_min, w_max)
        """
        # 计算速度范围（受机器人性能限制）
        v_max_robot = self.max_linear_velocity
        v_min_robot = self.min_linear_velocity
        w_max_robot = self.max_angular_velocity
        w_min_robot = self.min_angular_velocity
        
        # 计算加速度可达范围
        v_max_accel = current_v + self.max_linear_accel * 0.1  # 0.1s控制周期
        v_min_accel = current_v - self.max_linear_accel * 0.1
        w_max_accel = current_w + self.max_angular_accel * 0.1
        w_min_accel = current_w - self.max_angular_accel * 0.1
        
        # 动态窗口 = 性能限制 ∩ 加速度限制
        v_min = max(v_min_robot, v_min_accel)
        v_max = min(v_max_robot, v_max_accel)
        w_min = max(w_min_robot, w_min_accel)
        w_max = min(w_max_robot, w_max_accel)
        
        return (v_min, v_max, w_min, w_max)
    
    def _predict_trajectory(self, x, y, theta, v, w, steps=None):
        """预测机器人轨迹
        
        使用简单的运动学模型预测轨迹
        
        参数：
            x, y (float): 当前位置
            theta (float): 当前朝向
            v (float): 线速度
            w (float): 角速度
            steps (int): 预测步数
        
        返回：
            list: 轨迹点列表 [(x1,y1), (x2,y2), ...]
        """
        if steps is None:
            steps = int(self.prediction_time / 0.1)
        
        dt = self.prediction_time / steps
        trajectory = [(x, y)]
        
        for _ in range(steps):
            # 圆弧运动模型
            if abs(w) < 1e-6:  # 直线运动
                x += v * cos(theta) * dt
                y += v * sin(theta) * dt
            else:  # 圆弧运动
                r = v / w
                theta += w * dt
                x += r * (sin(theta) - sin(theta - w * dt))
                y -= r * (cos(theta) - cos(theta - w * dt))
            
            trajectory.append((x, y))
        
        return trajectory
    
    def _evaluate_trajectory(self, trajectory, goal_pose, velocity):
        """评估轨迹的优劣
        
        评分指标：
        1. 距离障碍物的距离（越远越好）
        2. 朝向目标的角度（越小越好）
        3. 速度（越大越好，在满足安全的前提下）
        
        参数：
            trajectory (list): 预测轨迹
            goal_pose (tuple): 目标位置 (x, y)
            velocity (float): 速度
        
        返回：
            float: 综合评分
        """
        goal_x, goal_y = goal_pose
        
        # ==================== 1. 距离障碍物评分 ====================
        min_dist_to_obs = float('inf')
        
        for x, y in trajectory:
            cost = self.slam_handler.get_cost_at_position(x, y)
            
            # 转换成本为距离（估计值）
            dist_to_obs = (1 - cost) * self.ob_dist_threshold
            
            min_dist_to_obs = min(min_dist_to_obs, dist_to_obs)
            
            # 碰撞检查
            if self.slam_handler.is_collision(x, y):
                return -np.inf
        
        # 距离评分（障碍物太近则评分极低）
        if min_dist_to_obs < 0.1:
            heading_score = -np.inf
        else:
            heading_score = min_dist_to_obs
        
        # ==================== 2. 朝向评分 ====================
        final_x, final_y = trajectory[-1]
        angle_to_goal = np.arctan2(
            goal_y - final_y,
            goal_x - final_x
        )
        angle_error = abs(angle_to_goal - trajectory[-1][0])  # 简化计算
        angle_score = -angle_error
        
        # ==================== 3. 速度评分 ====================
        velocity_score = velocity
        
        # ==================== 综合评分 ====================
        total_score = (
            self.heading_weight * heading_score +
            self.distance_weight * angle_score +
            self.velocity_weight * velocity_score
        )
        
        return total_score
    
    def generate_waypoints(self, path, lookahead_distance=0.5):
        """从全局路径生成局部路径点
        
        参数：
            path (list): 全局路径点列表
            lookahead_distance (float): 前看距离(m)
        
        返回：
            tuple: (next_waypoint, remaining_path)
        """
        if not path or len(path) < 2:
            return None, path
        
        # 找到前看点
        for i, (x, y) in enumerate(path):
            if np.hypot(x - path[0][0], y - path[0][1]) >= lookahead_distance:
                return path[i], path[i:]
        
        # 如果没找到前看点，返回终点
        return path[-1], [path[-1]]


# 示例使用
if __name__ == "__main__":
    print("Local Path Planner Module Loaded")
