#ifndef NAV2_MPC_PLANNER__MPC_PLANNER_HPP_
#define NAV2_MPC_PLANNER__MPC_PLANNER_HPP_

#include "nav2_core/controller.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "nav_msgs/msg/path.hpp"
#include "tf2_ros/buffer.h"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"
#include <Eigen/Dense>
#include <cmath>

namespace nav2_mpc_planner
{
// 完全匹配Humble的Controller接口（仅实现纯虚函数）
class MPCPlanner : public nav2_core::Controller
{
public:
  MPCPlanner() = default;
  ~MPCPlanner() = default;

  // 1. 必须实现的纯虚函数（Humble核心接口）
  void configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
    std::string name,
    std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) override;

  void cleanup() override;
  void activate() override;
  void deactivate() override;

  void setPlan(const nav_msgs::msg::Path & path) override;

  geometry_msgs::msg::TwistStamped computeVelocityCommands(
    const geometry_msgs::msg::PoseStamped & curr_pose,
    const geometry_msgs::msg::Twist & curr_vel,
    nav2_core::GoalChecker * goal_checker) override;

  void setSpeedLimit(const double & speed_limit, const bool & percentage) override;

  // 2. 删除Humble中不存在的override函数（核心修复！）
  bool isGoalReached() { return is_goal_reached_; }
  void reset() { is_goal_reached_ = false; }

private:
  // 差分驱动运动学模型
  Eigen::Vector3d model(const Eigen::Vector3d & x, const Eigen::Vector2d & u, double dt);
  
  // 简化MPC求解
  Eigen::Vector2d solveMPC(const Eigen::Vector3d & curr_pose, const std::vector<Eigen::Vector3d> & ref_path);
  
  // 自定义yaw求解（适配Humble）
  inline double get_yaw(const geometry_msgs::msg::Quaternion & q)
  {
    return atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z));
  }

  // 成员变量
  rclcpp_lifecycle::LifecycleNode::SharedPtr node_;
  std::shared_ptr<tf2_ros::Buffer> tf_;
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
  nav_msgs::msg::Path global_path_;
  std::string name_;
  bool is_goal_reached_{false};

  // MPC参数
  double dt_ = 0.1;          
  double max_vx_ = 0.26;     
  double max_vth_ = 1.0;     
  double xy_tol_ = 0.25;
  double yaw_tol_ = 0.25;
};

}  // namespace nav2_mpc_planner

#endif  // NAV2_MPC_PLANNER__MPC_PLANNER_HPP_

